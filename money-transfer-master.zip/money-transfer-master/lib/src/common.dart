import 'package:flutter/material.dart';

const white = Colors.white;
const red = Colors.red;
const grey = Colors.grey;